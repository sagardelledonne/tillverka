import math
from PIL import Image, ImageDraw
C=(400,437)
face=[(42,578),(160,700),(295,700),(322,673),(455,673),(535,590),(468,492),(400,575)]
chan=[(42,573),(100,515),(295,515),(325,490),(462,490),(398,572)]
def rot(p,deg):
    t=math.radians(deg); x,y=p[0]-C[0],p[1]-C[1]
    return (C[0]+x*math.cos(t)-y*math.sin(t), C[1]+x*math.sin(t)+y*math.cos(t))
base=Image.open('ig-logo-150.jpg').convert('L').crop((25,25,125,125)).resize((800,800), Image.BICUBIC).convert('RGB')
ov=Image.new('RGB',(800,800),(0,0,0)); d=ImageDraw.Draw(ov)
for k in range(3):
    f=[rot(p,120*k) for p in face]; c=[rot(p,120*k) for p in chan]
    d.polygon(f,fill=(255,255,255))
    d.polygon(c,fill=(0,0,0),outline=(255,255,255),width=7)
Image.blend(base,ov,0.5).save('logo-overlay.png')
ov.save('logo-recon.png')
