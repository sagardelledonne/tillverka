import math, json
from PIL import Image
C=(400,437); S=400
face=[(42,578),(160,700),(295,700),(322,673),(455,673),(535,590),(468,492),(400,575)]
chan=[(42,573),(100,515),(295,515),(325,490),(462,490),(398,572)]
def rot(p,deg):
    t=math.radians(deg); x,y=p[0]-C[0],p[1]-C[1]
    return (x*math.cos(t)-y*math.sin(t), x*math.sin(t)+y*math.cos(t))
def norm(poly): return [[round(x/S,4), round(y/S,4)] for x,y in poly]
# base piece (bottom piece, unrotated), SVG coords (y down), centered on rotation center
face_n=norm([rot(p,0) for p in face]); chan_n=norm([rot(p,0) for p in chan])
allpts=[rot(p,120*k) for k in range(3) for p in face+chan]
xs=[p[0] for p in allpts]; ys=[p[1] for p in allpts]
print('bbox', min(xs)/S, max(xs)/S, min(ys)/S, max(ys)/S)
# SVG: viewBox in units *100
def path(poly, k):
    pts=[rot(p,120*k) for p in poly]
    return 'M'+' L'.join(f'{x/S*100:.2f} {y/S*100:.2f}' for x,y in pts)+' Z'
minx,maxx,miny,maxy=min(xs)/S*100,max(xs)/S*100,min(ys)/S*100,max(ys)/S*100
pad=4
vb=f'{minx-pad:.1f} {miny-pad:.1f} {maxx-minx+2*pad:.1f} {maxy-miny+2*pad:.1f}'
sw=7/S*100
def svg(fg, bg, extra=''):
    g=''
    for k in range(3):
        g+=f'<path d="{path(face,k)}" fill="{fg}"/>'
        g+=f'<path d="{path(chan,k)}" fill="{bg}" stroke="{fg}" stroke-width="{sw:.2f}" stroke-linejoin="miter"/>'
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{vb}"{extra}>{g}</svg>'
open('assets/img/logo-white.svg','w').write(svg('#ffffff','#000000'))
open('assets/img/logo-black.svg','w').write(svg('#0a0a0b','#ffffff'))
# currentColor version: channel is "cut out" -> use fill-rule evenodd with mask; simpler: channel fill = var
open('assets/img/logo-mark.svg','w').write(svg('currentColor','var(--logo-bg, #000)'))
# favicon: black circle + white mark
fav=f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="-110 -110 220 220"><circle r="110" fill="#000"/><g transform="scale(0.92) translate({-(minx+maxx)/2:.1f} {-(miny+maxy)/2:.1f})">'
for k in range(3):
    fav+=f'<path d="{path(face,k)}" fill="#fff"/><path d="{path(chan,k)}" fill="#000" stroke="#fff" stroke-width="{sw:.2f}"/>'
fav+='</g></svg>'
open('assets/img/favicon.svg','w').write(fav)
json.dump({'note':'Tillverka logo: 3 identical pieces rotated 0/120/240 deg (clockwise in SVG y-down space) around origin. Units: logo radius ~0.95. SVG coords (y down). For three.js negate y.','face':face_n,'channel':chan_n,'bbox':[minx/100,maxx/100,miny/100,maxy/100],'outlineWidth':round(7/S,4)}, open('_ricerca/logo-shape.json','w'), indent=1)
print(vb)
# photos -> webp
import os
m={'01-sgabelli-fuorisalone2026':'aura-sgabelli','02-gammino-dettagli':'gammino-dettaglio','03-gammino-sl1s':'gammino-scultura','04-gammino-studio':'gammino-studio','05-xerra-nylon-mjf':'xerra-nylon','06-ganesha-render':'ganesha','07-zigzig-lamp':'zigzig-lamp','08-flylaly-kitsch':'kitsch-flylaly','09-tobu-kitsch':'kitsch-tobu','10-zenlizard-kitsch':'kitsch-zenlizard','11-miniature-form3':'miniature-form3','12-tillien-alien':'tillien'}
for src,dst in m.items():
    im=Image.open(f'_ricerca/{src}.jpg').convert('RGB'); im.save(f'assets/img/lavori/{dst}.webp','WEBP',quality=86, method=6)
    print(dst, im.size, os.path.getsize(f'assets/img/lavori/{dst}.webp'))
Image.open('_ricerca/fb-cover-960.jpg').convert('RGB').save('assets/img/lavori/lab-diorama.webp','WEBP',quality=86)
